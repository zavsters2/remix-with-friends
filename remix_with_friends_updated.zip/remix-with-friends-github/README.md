## Welcome to Picsart Miniapps!

We're excited to have you here! 🎉 To get started with developing your Miniapps, we've compiled all the necessary information and resources you'll need.

### Quick Links

- **Miniapps Documentation:** Dive into our [Miniapps documentation](https://extensions-documentation.pages.dev/docs/getting-started/introduction) to understand the basics and advanced features of Miniapps development.

- **Cascade Design System:** Familiarize yourself with our [Cascade design system](https://storybook.picsart.tools/core/main/) to ensure your Miniapps follow our design guidelines and principles.

### Getting Started

**Start the Development Server:**

To begin development, start your server with the following command:

```bash
npm run dev
```

**Build Your Miniapp:**

- For staging environment:

```bash
npm run build
```

- For pre-production environment:

```bash
npm run build:preproduction
```

- For production environment:

```bash
npm run build:production
```

### Testing on a mobile device

Verify your Miniapp not only in a desktop browser but also on a physical phone. Use a tunneling tool to expose your local server to a public URL.

**localtunnel** (free, limited):

1. Add a `preview` section to your `vite.config.ts`:

```
preview: {
    cors: true,
    allowedHosts: true,
},
```

2. Build and start the preview server:

```bash
npm run build && npm run preview
```

3. Start the tunnel to the preview server port (default 4173):

```bash
npx localtunnel --port 4173
```

4. localtunnel will provide a public URL like `https://little-results-notice.loca.lt`. Open it in a browser and visit `https://loca.lt/mytunnelpassword` to get the password.

5. Open the editor on your phone with the provided URL:

```
https://picsart.com/create/editor?miniapp_server=https://little-results-notice.loca.lt
```

If your phone and computer have different external IPs, you may need to enter the password again.

**ngrok** (dev server, paid required):

1. Allow external hosts in `vite.config.ts`:

```
server: {
    cors: true,
    allowedHosts: true,
}
```

2. Run the dev server:

```bash
npm run dev
```

3. Start the ngrok tunnel to your dev port (replace `5173` if needed):

```bash
ngrok http 5173
```

4. A paid ngrok plan is required; it will not work at all without it.

5. Open the editor with the ngrok URL:

```
https://picsart.com/create/editor?miniapp_server=https://<your-ngrok-host>.ngrok-free.dev
```

**CI/CD Pipeline:**

In order to make the CI/CD work you need to add variables to your `.gitlab-ci.yml`. Use you miniapp id from deploy portal as a value for those variables

- for the production environment:

```bash
variables:
  ....
  MINIAPP_ID_PROD: '43s64903-f4fs-33d5-32d3-3r2f704o4fej' # Add your miniapp production id
  ....
```

- for the other environments:

```bash
variables:
  ....
  MINIAPP_ID_STAGE: '67jjy54h-6bg2-55d3-23k4-3d2g435d3sbk' # Add your miniapp stage id
  ....
```

- For production environment:

```bash
npm run build:production
```

**Repository Configuration (required for CI/CD):**

Ensure your `package.json` contains your GitLab repository URL so CI/CD can reference your repository correctly:

```json
{
  "repository": {
    "type": "git",
    "url": "git@gitlab.com:picsart/<your_repository_path>.git"
  }
}
```

### Need Help?

If you have any questions or run into any issues, don't hesitate to reach out to our development team at the **#miniapps-dev-support** channel . We're here to help you make your Miniapps a success!
