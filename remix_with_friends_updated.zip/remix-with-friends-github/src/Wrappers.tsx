import { useState } from 'react';
import type { ReactElement } from 'react';
import { createGenerateId, JssProvider, SheetsRegistry } from 'react-jss';
import useThemeChange from './hooks/useThemeChange';
import { getContext } from '@/context';
import { ReactINTLProvider } from '@picsart/rc/services/localization';
import errorLogger from '@picsart/growth-rc/services/errorLogger';
import useMount from '@/hooks/useMount';
import useOpen from '@/hooks/useOpen';
import type { ILanguagesCodes } from '@picsart/rc/types/data/languages';

const registry = new SheetsRegistry();
const generateId = createGenerateId({
  minify: import.meta.env.MODE === 'production',
});

function JSSProviderWrapper({ children }: { children: ReactElement }) {
  useThemeChange();
  return (
    <JssProvider generateId={generateId} registry={registry}>
      {children}
    </JssProvider>
  );
}

function JSSProviderWrapperWithoutDesignSystem({
  children,
}: {
  children: ReactElement;
}) {
  return (
    <JssProvider generateId={generateId} registry={registry}>
      {children}
    </JssProvider>
  );
}

export default function Provders({
  children,
  setupTheming,
}: {
  children: ReactElement;
  setupTheming: boolean;
}) {
  const [language, setLanguage] = useState<ILanguagesCodes>(
    getContext().general.language.getState() as ILanguagesCodes
  );

  useMount(() => {
    getContext().general.language.subscribe((nextLanguage: ILanguagesCodes) =>
      setLanguage(nextLanguage)
    );
  });

  const isOpen = useOpen(() => {
    errorLogger.leaveBreadcrumb('opening the miniapp now', {
      category: isOpen,
    });
  });

  return (
    <ReactINTLProvider
      projectName="pa_miniapps"
      language={language}
      withoutReusableComponents
    >
      {setupTheming ? (
        <JSSProviderWrapper>{children}</JSSProviderWrapper>
      ) : (
        <JSSProviderWrapperWithoutDesignSystem>
          {children}
        </JSSProviderWrapperWithoutDesignSystem>
      )}
    </ReactINTLProvider>
  );
}
