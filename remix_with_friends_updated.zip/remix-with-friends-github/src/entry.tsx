import { createRoot } from 'react-dom/client';

import {
  IPicsartToolPubSub
} from '@picsart/miniapps-sdk/types/types';

import Wrappers from './Wrappers';
import App from './components/App';
import setupContext from './context';

const setup = ({
  containerId,
  setupTheming = true,
  pubsub 
}: {
  containerId: string;
  setupTheming?: boolean;
  pubsub?: IPicsartToolPubSub
}) => {
  const container = document.getElementById(containerId)!;
  const root = createRoot(container);
  setupContext({ pubsub });
  root.render(
    <Wrappers setupTheming={setupTheming}>
      <App />
    </Wrappers>
  );
  return {
    unmount: () => root.unmount(),
  };
};

export default setup;
