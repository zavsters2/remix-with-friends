import { createUseStyles } from 'react-jss';

const useStyles = createUseStyles({
  '@keyframes fadeIn': {
    from: {
      opacity: 0,
      transform: 'translateX(-50%) translateY(-10px)',
    },
    to: {
      opacity: 1,
      transform: 'translateX(-50%) translateY(0)',
    },
  },
  '@keyframes fadeOut': {
    from: {
      opacity: 1,
      transform: 'translateX(-50%) translateY(0)',
    },
    to: {
      opacity: 0,
      transform: 'translateX(-50%) translateY(-10px)',
    },
  },

  // Desktop: Fullscreen overlay with centered content
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    '@media (max-width: 768px)': {
      alignItems: 'flex-end',
    },
  },

  snackbarContainer: {
    position: 'absolute',
    top: 24,
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 1001,
    whiteSpace: 'nowrap',
    animation: '$fadeIn 0.3s ease-out forwards',
  },

  snackbarContainerExit: {
    animation: '$fadeOut 0.3s ease-out forwards',
  },
  
  // Desktop: Centered card layout
  // Mobile: Bottom sheet layout
  sheet: {
    width: '100%',
    maxWidth: 440,
    backgroundColor: '#1A1A1A',
    borderRadius: 24,
    padding: '56px 24px 32px',
    display: 'flex',
    flexDirection: 'column',
    gap: 20,
    position: 'relative',
    '@media (max-width: 768px)': {
      maxWidth: '100%',
      borderRadius: '24px 24px 0 0',
      padding: '12px 24px 32px',
      maxHeight: '90vh',
      overflowY: 'auto',
    },
  },
  
  // Close button inside the sheet - centered between top edge and hero
  closeButton: {
    position: 'absolute',
    top: 12,
    right: 16,
    zIndex: 10,
    '& button': {
      color: '#FFFFFF !important',
      '& svg': {
        fill: '#FFFFFF',
      },
    },
    '@media (max-width: 768px)': {
      display: 'none',
    },
  },
  
  // Drag handle - only visible on mobile
  dragHandle: {
    width: 36,
    height: 4,
    backgroundColor: '#4A4A4A',
    borderRadius: 2,
    margin: '0 auto 8px',
    display: 'none',
    '@media (max-width: 768px)': {
      display: 'block',
    },
  },
  
  heroSection: {
    background: 'linear-gradient(135deg, #FF2D92 0%, #00B4D8 100%)',
    borderRadius: 16,
    padding: 20,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 180,
    position: 'relative',
    overflow: 'hidden',
  },
  
  heroImageContainer: {
    display: 'flex',
    gap: 12,
    alignItems: 'center',
  },
  
  heroImage: {
    width: 120,
    height: 140,
    borderRadius: 12,
    objectFit: 'cover',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
  },
  
  remixBadge: {
    position: 'absolute',
    right: 20,
    top: '50%',
    transform: 'translateY(-50%)',
    backgroundColor: 'white',
    borderRadius: 8,
    padding: '8px 12px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 4,
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
  },
  
  remixIcon: {
    width: 24,
    height: 24,
  },
  
  remixText: {
    fontSize: 12,
    fontWeight: 500,
    color: '#1A1A1A',
  },
  
  textContent: {
    textAlign: 'center',
  },
  
  title: {
    fontSize: 20,
    fontWeight: 700,
    color: '#FFFFFF',
    margin: '0 0 8px 0',
  },
  
  subtitle: {
    fontSize: 14,
    lineHeight: 1.5,
    color: '#999999',
    margin: 0,
  },
  
  shareSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: 8,
  },
  
  shareLabel: {
    fontSize: 14,
    color: '#999999',
    margin: 0,
  },
  
  shareLinkContainer: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
  },
  
  textFieldWrapper: {
    flex: 1,
  },
  
  copyButton: {
    flexShrink: 0,
  },
  
  ctaButton: {
    marginTop: 8,
  },
});

export default useStyles;
