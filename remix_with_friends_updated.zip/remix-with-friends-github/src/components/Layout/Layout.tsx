import {
  EditorBlank,
  EditorBlankBody,
  EditorBlankFooter,
  EditorBlankHeader,
} from '@picsart/design-system/components/EditorBlank';
import { Button, ButtonSizeMD } from '@picsart/design-system/components/Button';
import { BadgeTypes } from '@picsart/design-system/components/Badge';
import { getContext } from '@/context';
import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import useStyles from './styles';
import type { LayoutType } from './types';
import addImageLayer from '@/lib/addImageLayer';

function Layout({ title }: LayoutType) {
  const styles = useStyles({ isHacker: true });

  return (
    <EditorBlank
      __isRootEntryElement
      header={
        <EditorBlankHeader
          closeAction={async () => {
            await getContext().handlers.close();
          }}
          title={title}
          count={1000}
          badge={BadgeTypes.Pro}
        />
      }
      body={
        <EditorBlankBody>
          <div className={styles.content}>
            <Text className={styles.code} elementType={TextElementTypes.H1}>
              "Happy Hacking!!!"
            </Text>
          </div>
        </EditorBlankBody>
      }
      footer={
        <EditorBlankFooter>
          <Button isFullWidth size={ButtonSizeMD} onClick={addImageLayer}>
            Add image to the canvas
          </Button>
        </EditorBlankFooter>
      }
    />
  );
}

export default Layout;
