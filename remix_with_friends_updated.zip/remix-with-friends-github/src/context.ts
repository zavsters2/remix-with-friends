import { createContext } from '@picsart/miniapps-sdk';
import {
  ICreateContextOptions,
  IGeneralContext,
} from '@picsart/miniapps-sdk/types/types';

type AppContextProvider = {
  getContext: () => IGeneralContext;
  destroyContext: () => void;
};

let appContext: null | AppContextProvider = null;

const setupContext = (options?: ICreateContextOptions) => {
  appContext = createContext(options);

  return {
    unmount: () => {
      if (!appContext) {
        throw new Error('App context not initialized');
      }
      appContext.destroyContext();
    },
  };
};

const getContext = () => {
  if (!appContext) {
    throw new Error('App context not initialized');
  }
  return appContext.getContext();
};
export { getContext };

export default setupContext;
