import { useState, useEffect } from 'react';

/**
 * Hook to generate and manage a remix link (mocked for MVP)
 */
export function useRemixLink() {
  const [remixLink, setRemixLink] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to generate remix link
    const generateLink = async () => {
      setIsLoading(true);
      
      // Mock delay to simulate network request
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Generate a mock remix ID
      const remixId = Math.random().toString(36).substring(2, 10);
      const link = `https://picsart.com/remix/${remixId}`;
      
      setRemixLink(link);
      setIsLoading(false);
    };

    generateLink();
  }, []);

  const regenerateLink = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 300));
    const remixId = Math.random().toString(36).substring(2, 10);
    setRemixLink(`https://picsart.com/remix/${remixId}`);
    setIsLoading(false);
  };

  return { remixLink, isLoading, regenerateLink };
}

export default useRemixLink;
