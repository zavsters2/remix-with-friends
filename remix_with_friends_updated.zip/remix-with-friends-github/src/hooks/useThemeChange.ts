import { getContext } from '@/context';
import {
  ThemeDarkValues,
  ThemeLightValues,
} from '@picsart/design-system/foundation/colors';
import { useFoundation } from '@picsart/design-system/foundation/initFoundation';
import { useState, useEffect } from 'react';
import useOpen from './useOpen';

const themes = [
  {
    key: 'light',
    value: ThemeLightValues,
    selected: false,
  },
  {
    key: 'dark',
    value: ThemeDarkValues,
    selected: true, // Default to dark theme
  },
];

const useThemeChange = () => {
  const [themeMode, setThemeMode] = useState(themes);
  
  // Set dark theme by default on mount
  useEffect(() => {
    setThemeMode((prevThemes) =>
      prevThemes.map((theme) => ({
        ...theme,
        selected: theme.key === 'dark',
      }))
    );
  }, []);

  useOpen(() => {
    return getContext().general.theme.subscribe(
      (value) => {
        setThemeMode((prevThemes) =>
          prevThemes.map((theme) => ({
            ...theme,
            selected: theme.key === value,
          }))
        );
      },
      { needPrevious: true }
    );
  });

  useFoundation({ themes: themeMode });
};

export default useThemeChange;
