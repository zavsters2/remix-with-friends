import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import open from 'open';
import { resolve } from 'path';
import { copyFileSync } from 'fs';

function copyManifestPlugin() {
  return {
    name: 'copy-manifest-plugin',
    buildStart() {
      const src = resolve(__dirname, 'extension-manifest.json');
      const dest = resolve(__dirname, 'public', 'extension-manifest.json');
      copyFileSync(src, dest);
      console.log(`Copied ${src} → ${dest}`);
    },
  };
}

// Server configuration
const PICSART_HOST_URL = 'https://picsart.com/create/editor';

// https://vite.dev/config/
export default defineConfig({
  build: {
    outDir: 'build',
  },
  define: {
    'process.env': {},
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
  plugins: [
    react(),
    {
      name: 'Open the miniapp in the editor',
      configureServer(server) {
        server.httpServer?.once('listening', () => {
          const url = `http://localhost:${server.config.server.port}`;
          const encodedLocalhostUrl = encodeURIComponent(url);
          const urlToOpen = `${PICSART_HOST_URL}?miniapp_server=${encodedLocalhostUrl}`;

          console.log(
            `Click to the link to start development 👉 ${urlToOpen}\n`
          );

          open(urlToOpen);
        });
      },
    },
    copyManifestPlugin(),
  ],
  server: {
    cors: true,
  },
});
