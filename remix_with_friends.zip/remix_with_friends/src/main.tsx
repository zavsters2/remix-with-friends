import errorLogger, {
  scopeType,
  bugsnagStagesEnum,
  BUGSNAG_STATUSES,
} from '@picsart/growth-rc/services/errorLogger';
import webVitals from '@picsart/rc/services/webVitals';
import { getContext } from '@/context';
import setup from '@/entry';

const BUGSNAG_API_KEY = import.meta.env.VITE_BUGSNAG_API_KEY;

const miniappName = import.meta.env.VITE_APP_MINIAPP_NAME;
const appVersion = import.meta.env.VITE_APP_VERSION;
const currentBranchName = import.meta.env.VITE_APP_CURRENT_BRANCH_NAME;
const deploymentBranchName = import.meta.env.VITE_APP_DEPLOYMENT_BRANCH_NAME;
const releaseBranchName = import.meta.env
  .VITE_APP_RELEASE_CANDIDATE_BRANCH_NAME;
const onlyAppVersion = import.meta.env.VITE_APP_ONLY_APP_VERSION_FOR_BUGSNAG;

if (
  miniappName !== 'miniapp-id' &&
  BUGSNAG_API_KEY &&
  currentBranchName &&
  (currentBranchName === deploymentBranchName ||
    currentBranchName === releaseBranchName)
) {
  // @ts-expect-error: legacy type error
  bugsnagStagesEnum[bugsnagStagesEnum.miniapp_name_stage] = `${miniappName}${
    /^\d+.\d+.\d+-beta.\d+$/.test(appVersion) ? '-stage' : ''
  }`;
  errorLogger
    .init({
      apiKey: BUGSNAG_API_KEY,
      releaseStage: bugsnagStagesEnum.miniapp_name_stage,
      appVersion: onlyAppVersion ? appVersion : `${miniappName}-${appVersion}`,
      scope: scopeType.miniapps,
      project: miniappName,
    })
    .catch((error) => errorLogger.trigger(error, BUGSNAG_STATUSES.ERROR));
}

setup({ containerId: 'root' });

webVitals(
  window.location.href,
  miniappName,
  getContext().handlers.sendAnalytics
);