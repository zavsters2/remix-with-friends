import { createUseStyles } from 'react-jss';
import {
  FontSizes,
  LineHeights,
} from '@picsart/design-system/foundation/typography';
import {
  PrimaryColors,
  SecondaryColors,
} from '@picsart/design-system/foundation/colors';
import { Timings } from '@picsart/design-system/foundation/timings';
import type { LayoutStylesType } from './types';

const useStyles = createUseStyles<string, LayoutStylesType>(
  {
    content: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
    },
    '@keyframes animation': {
      from: {
        backgroundPosition: 0,
      },
      to: {
        backgroundPosition: '100%',
      },
    },
    code: {
      display: ({ isHacker }: LayoutStylesType) => isHacker && 'inline-block',
      fontSize: FontSizes.s24,
      lineHeight: LineHeights.l32,
      backgroundImage: `linear-gradient(
      45deg,
      ${PrimaryColors.base.default},
      ${SecondaryColors.base.default},
      ${SecondaryColors.base.default},
      ${PrimaryColors.base.default}
      )`,
      backgroundSize: ['300%', '100%'],
      backgroundClip: 'text',
      color: 'transparent',
      animation: `$animation ${Timings.long} linear infinite`,
    },
  },
  {
    name: 'layout',
  },
);

export default useStyles;
