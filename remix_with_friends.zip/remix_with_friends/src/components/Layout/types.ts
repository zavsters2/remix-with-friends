export type LayoutType = {
  title: string;
};

export type LayoutStylesType = {
  isHacker: boolean;
};
