import useStyles from './styles';

function HeroSection() {
  const styles = useStyles();

  return (
    <div className={styles.heroSection}>
      <div className={styles.heroImageContainer}>
        {/* Placeholder images representing the remix concept */}
        <div 
          className={styles.heroImage} 
          style={{ 
            background: 'linear-gradient(180deg, #2DD4BF 0%, #0891B2 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: 40,
          }}
        >
          🎨
        </div>
        <div 
          className={styles.heroImage} 
          style={{ 
            background: 'linear-gradient(180deg, #F472B6 0%, #EC4899 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: 40,
            marginLeft: -30,
            zIndex: 1,
          }}
        >
          ✨
        </div>
      </div>
      
      {/* Remix badge */}
      <div className={styles.remixBadge}>
        <span style={{ fontSize: 20 }}>🔄</span>
        <span className={styles.remixText}>Remix</span>
      </div>
    </div>
  );
}

export default HeroSection;
