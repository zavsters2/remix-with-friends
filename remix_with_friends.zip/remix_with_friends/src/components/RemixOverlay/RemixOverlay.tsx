import { Button, ButtonVariants, ButtonSkinPrimary, ButtonSkinAbsoluteWhite, ButtonSizeLG, ButtonSizeMD } from '@picsart/design-system/components/Button';
import { Snackbar, SnackbarSkins } from '@picsart/design-system/components/Snackbar';
import { IconCross } from '@picsart/design-system/foundation/icons/IconCross';
import useRemixLink from '@/hooks/useRemixLink';
import useCopyToClipboard from '@/hooks/useCopyToClipboard';
import HeroSection from './HeroSection';
import ShareSection from './ShareSection';
import useStyles from './styles';

interface RemixOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

function RemixOverlay({ isOpen, onClose }: RemixOverlayProps) {
  const styles = useStyles();
  const { remixLink, isLoading } = useRemixLink();
  const { isCopied, copyToClipboard, resetCopied } = useCopyToClipboard();

  const handleCopy = () => {
    if (remixLink) {
      copyToClipboard(remixLink);
    }
  };

  const handleRemixTogether = async () => {
    // Copy link and trigger native share if available
    await copyToClipboard(remixLink);
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Remix with me on Picsart!',
          text: 'Check out my creation and add your own twist!',
          url: remixLink,
        });
      } catch (error) {
        // User cancelled or share failed - link is already copied
        console.log('Share cancelled or failed, link copied to clipboard');
      }
    }
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    // Close when clicking the overlay background
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.overlay} onClick={handleOverlayClick}>
      {/* Confirmation Snackbar */}
      {isCopied && (
        <div className={styles.snackbarContainer}>
          <Snackbar
            title="Link copied!"
            skin={SnackbarSkins.Success}
            handleClose={resetCopied}
          />
        </div>
      )}
      
      <div className={styles.sheet}>
        {/* Close button for desktop - inside the sheet */}
        <div className={styles.closeButton}>
          <Button
            variant={ButtonVariants.Text}
            skin={ButtonSkinAbsoluteWhite}
            size={ButtonSizeMD}
            centerIcon={IconCross}
            onClick={onClose}
          />
        </div>
        
        {/* Drag handle */}
        <div className={styles.dragHandle} />
        
        {/* Hero section with gradient and images */}
        <HeroSection />
        
        {/* Title and subtitle */}
        <div className={styles.textContent}>
          <h2 className={styles.title}>Picsart is more fun with friends!</h2>
          <p className={styles.subtitle}>
            Share your creation with friends! They can add effects, stickers, and more. 
            Remix back and forth, and save your favorite collaborations.
          </p>
        </div>
        
        {/* Share link section */}
        <ShareSection
          remixLink={remixLink}
          isLoading={isLoading}
          isCopied={isCopied}
          onCopy={handleCopy}
        />
        
        {/* CTA Button */}
        <div className={styles.ctaButton}>
          <Button
            variant={ButtonVariants.Filled}
            skin={ButtonSkinPrimary}
            size={ButtonSizeLG}
            isFullWidth
            onClick={handleRemixTogether}
            isDisabled={isLoading}
          >
            Remix together
          </Button>
        </div>
      </div>
    </div>
  );
}

export default RemixOverlay;
