import { TextField } from '@picsart/design-system/components/TextField';
import { Button, ButtonVariants, ButtonSizeMD } from '@picsart/design-system/components/Button';
import { IconLink } from '@picsart/design-system/foundation/icons/IconLink';
import { IconCopy } from '@picsart/design-system/foundation/icons/IconCopy';
import { IconTick } from '@picsart/design-system/foundation/icons/IconTick';
import useStyles from './styles';

interface ShareSectionProps {
  remixLink: string;
  isLoading: boolean;
  isCopied: boolean;
  onCopy: () => void;
}

function ShareSection({ remixLink, isLoading, isCopied, onCopy }: ShareSectionProps) {
  const styles = useStyles();

  return (
    <div className={styles.shareSection}>
      <p className={styles.shareLabel}>Share link</p>
      <div className={styles.shareLinkContainer}>
        <div className={styles.textFieldWrapper}>
          <TextField
            value={isLoading ? 'Generating link...' : remixLink}
            isReadOnly
            startIcon={IconLink}
            placeholder="https://picsart.com/remix"
          />
        </div>
        <div className={styles.copyButton}>
          <Button
            variant={ButtonVariants.Outline}
            size={ButtonSizeMD}
            centerIcon={isCopied ? IconTick : IconCopy}
            onClick={onCopy}
            isDisabled={isLoading}
          />
        </div>
      </div>
    </div>
  );
}

export default ShareSection;
