import { useState, useEffect } from 'react';
import useOpen from '@/hooks/useOpen';
import RemixOverlay from './RemixOverlay';
import { Preloader } from '@picsart/design-system/components/Preloader';
import { getContext } from '@/context';

function App() {
  const isOpen = useOpen();
  const [isOverlayOpen, setIsOverlayOpen] = useState(true);
  const [forceShow, setForceShow] = useState(false);

  // Fallback: if SDK doesn't trigger onOpen within 3 seconds, show UI anyway
  useEffect(() => {
    const timeout = setTimeout(() => {
      if (!isOpen) {
        console.log('SDK onOpen timeout - showing UI anyway');
        setForceShow(true);
      }
    }, 3000);

    return () => clearTimeout(timeout);
  }, [isOpen]);

  const handleClose = async () => {
    setIsOverlayOpen(false);
    try {
      // Close the miniapp when overlay is dismissed
      await getContext().handlers.close();
    } catch (error) {
      console.log('Close handler not available:', error);
    }
  };

  if (!isOpen && !forceShow) {
    return <Preloader />;
  }

  return (
    <RemixOverlay 
      isOpen={isOverlayOpen} 
      onClose={handleClose} 
    />
  );
}

export default App;
