import { getContext } from '@/context';

import {
  createReplayImageLayer,
  findReplayGroups,
} from '@picsart/web-replay-sdk/context';

export default async function addImageLayer() {
  const context = getContext();

  // Step 1: Create your layer with the replay SDK.
  const replayImageLayer = createReplayImageLayer({
    name: 'Image layer',
    uuid: crypto.randomUUID(),
    mediaType: 'PHOTO',
    locked: false,
    meta: {},
    props: {
      scaleY: 3,
      scaleX: 3,
      image: {
        location:
          'https://cdn141.picsart.com/359086361085201.jpg?type=webp&to=min&r=150',
        type: 'photo',
        id: 'some image id',
        width: 300,
        height: 300,
      },
    },
  });

  // Step 2: Add it to the replay context. Note that here, the canvas group is the main canvas scene.
  context.scene.updateReplay((draftReplay) => {
    const groups = findReplayGroups(draftReplay);
    const canvasGroup = groups.filter((group) =>
      context.scene.hasLayerMediaType(group, 'CANVAS_GROUP')
    )[0];
    canvasGroup.props.children.value.push(replayImageLayer.uuid);

    draftReplay.context.layers[replayImageLayer.uuid] = replayImageLayer;
  });

  // Step 3: Send information to the host app.
  await context.scene.sync();
}
