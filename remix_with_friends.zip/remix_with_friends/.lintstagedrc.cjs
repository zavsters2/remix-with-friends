const micromatch = require('micromatch');

const extensions = ['**/*.ts'];

const analyzeStagedFiles = (allStagedFiles) => {
  const changedCodeFiles = micromatch(allStagedFiles, extensions);
  return [`eslint --fix ${changedCodeFiles.join(' ')}`, 'tsc --noEmit'];
};

module.exports = analyzeStagedFiles;
