# Picsart App - Agent Guide

## Overview

This project creates a Picsart App, a React SPA that runs inside Picsart Editor in a sandboxed iframe or native app webview. Picsart Apps are also known as Picsart Miniapps.

## Dependencies

- Miniapps SDK `@picsart/miniapps-sdk` - Main SDK library for interacting with the host app.
- Picsart UI kit `@picsart/design-system` - Also known as Cascade Design System. UI components library built with React and CSS-in-JS. Prefer design system components over plain HTML elements.
- Web Replay SDK `@picsart/web-replay-sdk` - API for manipulating the current editor scene.

## MCP Servers

Project includes MCP server setup for Cursor and VS Code.

- `miniapps-dev-mcp` - Provides App SDK and Replay SDK documentation
- `cascade-ds-mcp` - Provides Cascade Design System component documentation and examples
- `core-sdk-mcp` - Provides miniapps-sdk, web-replay, and web-layering libraries source code
