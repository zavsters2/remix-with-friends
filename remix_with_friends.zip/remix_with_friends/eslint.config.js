import js from '@eslint/js';
import globals from 'globals';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import tseslint from 'typescript-eslint';
import { globalIgnores } from 'eslint/config';

export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs['recommended-latest'],
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    rules: {
      'no-bitwise': [0],
      'no-plusplus': [0],
      'import/no-cycle': [0],
      'no-return-assign': [0],
      'consistent-return': [0],
      'no-nested-ternary': [0],
      'no-case-declarations': [0],
      'no-underscore-dangle': [0],
      'class-methods-use-this': [0],
      'no-restricted-properties': [0],
      'import/no-named-as-default': [0],
      '@typescript-eslint/require-await': [0],
      '@typescript-eslint/no-unsafe-call': [0],
      '@typescript-eslint/await-thenable': [0],
      '@typescript-eslint/ban-ts-comment': [0],
      '@typescript-eslint/no-unsafe-return': [0],
      '@typescript-eslint/naming-convention': [0],
      '@typescript-eslint/default-param-last': [0],
      '@typescript-eslint/no-unsafe-argument': [0],
      '@typescript-eslint/no-misused-promises': [0],
      '@typescript-eslint/no-unsafe-assignment': [0],
      '@typescript-eslint/no-use-before-define': [0],
      '@typescript-eslint/restrict-plus-operands': [0],
      '@typescript-eslint/no-unused-expressions': [0],
      '@typescript-eslint/no-unsafe-member-access': [0],
      '@typescript-eslint/restrict-template-expressions': [0],
      'no-param-reassign': [
        'error',
        { props: true, ignorePropertyModificationsForRegex: ['^draft'] },
      ],
    },
  },
]);
